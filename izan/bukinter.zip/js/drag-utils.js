// Shared Drag & Drop Utilities

window.getEventCoords = function (e) {
  const isMouseEvent = e.type.includes("mouse");
  return {
    clientX: isMouseEvent ? e.clientX : (e.touches && e.touches[0] ? e.touches[0].clientX : 0),
    clientY: isMouseEvent ? e.clientY : (e.touches && e.touches[0] ? e.touches[0].clientY : 0)
  };
};

window.getDragScale = function () {
  return Math.min(window.innerWidth / 1280, window.innerHeight / 720) || 1;
};

window.checkCollision = function (item, dropZones, dragScale, options = {}) {
  const {
    padding = 20,
    useDistance = false,
    cropItemRect = false
  } = options;

  const itemRect = item.getBoundingClientRect();
  const itemColLeft = cropItemRect ? itemRect.left + itemRect.width * 0.5 : itemRect.left;
  const itemColRight = itemRect.right;
  const itemColTop = itemRect.top;
  const itemColBottom = cropItemRect ? itemRect.top + itemRect.height * 0.5 : itemRect.bottom;

  const itemCenterX = (itemRect.left + itemRect.right) / 2;
  const itemCenterY = (itemRect.top + itemRect.bottom) / 2;

  let collidedZone = null;
  let matchingCollidedZone = null;
  let minMatchingDistance = Infinity;
  let minCollidedDistance = Infinity;

  const collisionPadding = padding * dragScale;

  for (const dropZone of dropZones) {
    if (dropZone.dataset.target === "dummy") continue;

    const dropRect = dropZone.getBoundingClientRect();
    const isColliding = !(
      itemColRight < dropRect.left - collisionPadding ||
      itemColLeft > dropRect.right + collisionPadding ||
      itemColBottom < dropRect.top - collisionPadding ||
      itemColTop > dropRect.bottom + collisionPadding
    );

    if (isColliding) {
      if (useDistance) {
        if (dropZone.dataset.completed) continue;

        const dropCenterX = (dropRect.left + dropRect.right) / 2;
        const dropCenterY = (dropRect.top + dropRect.bottom) / 2;
        const dist = Math.hypot(itemCenterX - dropCenterX, itemCenterY - dropCenterY);

        const isMatching =
          ((item.dataset.target &&
            item.dataset.target === dropZone.dataset.target) ||
            (!item.dataset.target && item.dataset.correct === "true"));

        if (isMatching) {
          if (dist < minMatchingDistance) {
            minMatchingDistance = dist;
            matchingCollidedZone = dropZone;
          }
        } else {
          if (dist < minCollidedDistance) {
            minCollidedDistance = dist;
            collidedZone = dropZone;
          }
        }
      } else {
        if (!collidedZone && !dropZone.dataset.completed) {
          collidedZone = dropZone;
        }

        const isMatching =
          ((item.dataset.target &&
            item.dataset.target === dropZone.dataset.target) ||
            (!item.dataset.target && item.dataset.correct === "true"));

        if (isMatching && !dropZone.dataset.completed) {
          matchingCollidedZone = dropZone;
          break;
        }
      }
    }
  }

  return matchingCollidedZone || collidedZone;
};

window.setupDraggable = function (item, options = {}) {
  const {
    onStart = () => { },
    onMove = () => { },
    onEnd = () => { },
    rotation = 35,
    scale = 1.1,
    shouldLock = () => false
  } = options;

  let isDragging = false;
  let startX, startY;
  let currentX = 0;
  let currentY = 0;
  let dragScale = 1;
  let activeDragCleanup = null;

  const handleStart = (e) => {
    if (shouldLock()) return;
    isDragging = true;

    const { clientX, clientY } = window.getEventCoords(e);
    dragScale = window.getDragScale();

    startX = clientX - currentX * dragScale;
    startY = clientY - currentY * dragScale;

    item.style.zIndex = 1000;
    item.style.transition = "none";
    item.style.willChange = "transform";
    item.style.pointerEvents = "none";
    item.style.transform = `translate(${currentX}px, ${currentY}px) scale(${scale}) rotate(${rotation}deg)`;
    item.style.cursor = "grabbing";

    activeDragCleanup = () => {
      isDragging = false;
      document.removeEventListener("mousemove", handleMove);
      document.removeEventListener("mouseup", handleEnd);
      document.removeEventListener("touchmove", handleMove);
      document.removeEventListener("touchend", handleEnd);
      activeDragCleanup = null;
    };

    document.addEventListener("mousemove", handleMove, { passive: false });
    document.addEventListener("mouseup", handleEnd);
    document.addEventListener("touchmove", handleMove, { passive: false });
    document.addEventListener("touchend", handleEnd);

    onStart({ e, dragScale });
  };

  const handleMove = (e) => {
    if (!isDragging) return;
    e.preventDefault();

    const { clientX, clientY } = window.getEventCoords(e);

    currentX = (clientX - startX) / dragScale;
    currentY = (clientY - startY) / dragScale;

    item.style.transform = `translate(${currentX}px, ${currentY}px) scale(${scale}) rotate(${rotation}deg)`;

    onMove({ e, currentX, currentY, dragScale });
  };

  const handleEnd = (e) => {
    if (!isDragging) return;
    if (activeDragCleanup) activeDragCleanup();

    item.style.transition = "transform 0.3s ease";
    item.style.willChange = "auto";
    item.style.pointerEvents = "auto";
    item.style.zIndex = 10;
    item.style.cursor = "grab";

    onEnd({
      e,
      currentX,
      currentY,
      dragScale,
      resetPosition: () => {
        currentX = 0;
        currentY = 0;
        item.style.transform = `translate(0px, 0px) scale(1)`;
      },
      snapBack: () => {
        currentX = 0;
        currentY = 0;
        item.style.transform = `translate(0px, 0px) scale(1) rotate(0deg)`;
      }
    });
  };

  item.addEventListener("mousedown", handleStart);
  item.addEventListener("touchstart", handleStart, { passive: true });

  return () => {
    item.removeEventListener("mousedown", handleStart);
    item.removeEventListener("touchstart", handleStart);
    if (activeDragCleanup) activeDragCleanup();
  };
};
