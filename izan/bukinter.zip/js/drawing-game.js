window.initDrawingGame = function (container, config) {
  const canvas = container.querySelector(".drawing-canvas");
  const pan = container.querySelector(".drawing-pan");
  const btnFinish = container.querySelector(".drawing-btn-finish");
  const plateStack = container.querySelector(".plate-stack");
  const btnNext = container.querySelector(".game-btn-next");
  const feedback = container.querySelector(".game-feedback");

  if (!canvas || !pan) return;

  if (feedback && config.startInstruction) {
    const text = config.startInstruction;
    window.showGameFeedback(
      feedback,
      `<span style="color:var(--color-wood-dark)">${text}</span>`,
      text,
      config.startAudio,
      config.hideStartSpeechBtn,
    );
  }

  const ctx = canvas.getContext("2d");
  let isDrawing = false;
  let drawCount = 0;
  const maxDraws = config.maxDraws || 3;
  let hasDrawnCurrent = false;
  let points = [];
  let bounds = {
    minX: Infinity,
    minY: Infinity,
    maxX: -Infinity,
    maxY: -Infinity,
  };

  function updateBounds(p) {
    if (p.x < bounds.minX) bounds.minX = p.x;
    if (p.x > bounds.maxX) bounds.maxX = p.x;
    if (p.y < bounds.minY) bounds.minY = p.y;
    if (p.y > bounds.maxY) bounds.maxY = p.y;
  }

  // Gunakan offscreen canvas untuk snapshot hardware-accelerated
  let offscreenCanvas = document.createElement("canvas");
  let offCtx = offscreenCanvas.getContext("2d");

  // Fungsi untuk menyesuaikan ukuran canvas dengan container (pan)
  function resizeCanvas() {
    const rect = pan.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return; // Abaikan jika masih hidden

    // Simpan gambar canvas sebelum resize (karena resize akan mereset context & gambar)
    let tempImage = null;
    if (hasDrawnCurrent) {
      tempImage = new Image();
      tempImage.src = canvas.toDataURL();
    }

    // Beri ukuran internal canvas yang sama dengan ukuran tampilannya
    canvas.width = rect.width;
    canvas.height = rect.height;

    offscreenCanvas.width = rect.width;
    offscreenCanvas.height = rect.height;

    // Reset style garis setiap resize
    setupContext();

    // Kembalikan gambar jika ada
    if (tempImage && tempImage.src) {
      tempImage.onload = () => {
        ctx.drawImage(tempImage, 0, 0, canvas.width, canvas.height);
      };
    }
  }

  function setupContext() {
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    // Gunakan perhitungan relatif agar proporsional dengan wajan
    ctx.lineWidth = config.lineWidth || Math.max(3, canvas.width * 0.02);

    const colors = config.drawColors || ["#F3C550"];
    const currentColor = colors[drawCount % colors.length];

    ctx.strokeStyle = currentColor;
    ctx.shadowBlur = 4;
    ctx.shadowColor = "rgba(0,0,0,0.2)";
  }

  // Gunakan ResizeObserver agar ukuran canvas otomatis benar saat popup muncul
  const resizeObserver = new ResizeObserver(() => {
    resizeCanvas();
  });
  resizeObserver.observe(pan);

  function getMousePos(e) {
    const rect = canvas.getBoundingClientRect();
    let clientX, clientY;

    if (e.touches && e.touches.length > 0) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    const scaleX = rect.width ? canvas.width / rect.width : 1;
    const scaleY = rect.height ? canvas.height / rect.height : 1;

    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY,
    };
  }

  const timeouts = [];
  let activeDragCleanup = null;

  window.destroyActiveGame = () => {
    resizeObserver.disconnect();
    timeouts.forEach((id) => clearTimeout(id));
    if (activeDragCleanup) activeDragCleanup();
    canvas.removeEventListener("mousedown", startDrawing);
    canvas.removeEventListener("mousemove", draw);
    canvas.removeEventListener("mouseup", stopDrawing);
    canvas.removeEventListener("mouseout", stopDrawing);
    canvas.removeEventListener("touchstart", startDrawing);
    canvas.removeEventListener("touchmove", draw);
    canvas.removeEventListener("touchend", stopDrawing);
    canvas.removeEventListener("touchcancel", stopDrawing);
  };

  function startDrawing(e) {
    e.preventDefault(); // Mencegah scrolling saat menggambar
    if (drawCount >= maxDraws) return;

    timeouts.forEach((id) => clearTimeout(id));
    timeouts.length = 0; // Clear the array

    isDrawing = true;
    hasDrawnCurrent = true;
    // btnFinish.classList.remove("hidden"); // Tidak dipakai lagi

    const p = getMousePos(e);
    points = [p];
    updateBounds(p);

    // Simpan status canvas (snapshot) ke offscreen canvas dengan cepat
    offCtx.clearRect(0, 0, offscreenCanvas.width, offscreenCanvas.height);
    offCtx.drawImage(canvas, 0, 0);
  }

  let isRendering = false;

  function draw(e) {
    e.preventDefault();
    if (!isDrawing) return;

    const p = getMousePos(e);
    points.push(p);
    updateBounds(p);

    if (!isRendering) {
      isRendering = true;
      requestAnimationFrame(() => {
        renderCurrentStroke();
        isRendering = false;
      });
    }
  }

  function renderCurrentStroke() {
    // Bersihkan canvas dan kembalikan ke snapshot dengan drawImage
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(offscreenCanvas, 0, 0);

    if (points.length === 0) return;

    ctx.beginPath();
    ctx.moveTo(points[0].x, points[0].y);

    if (points.length < 3) {
      const p = points[1] || points[0];
      ctx.lineTo(p.x, p.y);
      ctx.stroke();
      return;
    }

    // Gunakan Quadratic Curves agar garis melengkung dengan mulus
    let i = 1;
    for (; i < points.length - 2; i++) {
      const xc = (points[i].x + points[i + 1].x) / 2;
      const yc = (points[i].y + points[i + 1].y) / 2;
      ctx.quadraticCurveTo(points[i].x, points[i].y, xc, yc);
    }
    // Kurva untuk dua titik terakhir
    ctx.quadraticCurveTo(
      points[i].x,
      points[i].y,
      points[i + 1].x,
      points[i + 1].y,
    );
    ctx.stroke();
  }

  function stopDrawing(e) {
    if (!isDrawing) return;
    isDrawing = false;

    if (hasDrawnCurrent) {
      timeouts.push(setTimeout(() => {
        createDraggablePancake();
      }, 1000));
    }
  }

  // Event Listeners (Mouse)
  canvas.addEventListener("mousedown", startDrawing);
  canvas.addEventListener("mousemove", draw);
  canvas.addEventListener("mouseup", stopDrawing);
  canvas.addEventListener("mouseout", stopDrawing);

  // Event Listeners (Touch)
  canvas.addEventListener("touchstart", startDrawing, { passive: false });
  canvas.addEventListener("touchmove", draw, { passive: false });
  canvas.addEventListener("touchend", stopDrawing);
  canvas.addEventListener("touchcancel", stopDrawing);

  function createDraggablePancake() {
    // 1. Ambil gambar dari canvas yang sudah di-crop ke bounding box-nya
    const pad = ctx.lineWidth ? ctx.lineWidth * 1.5 : 20;
    let cropX = Math.max(0, bounds.minX - pad);
    let cropY = Math.max(0, bounds.minY - pad);
    let cropW = Math.min(
      canvas.width - cropX,
      bounds.maxX - bounds.minX + pad * 2,
    );
    let cropH = Math.min(
      canvas.height - cropY,
      bounds.maxY - bounds.minY + pad * 2,
    );

    if (cropW <= 0 || cropH <= 0 || bounds.minX === Infinity) {
      cropX = 0;
      cropY = 0;
      cropW = canvas.width;
      cropH = canvas.height;
    }

    let cropCanvas = document.createElement("canvas");
    cropCanvas.width = cropW;
    cropCanvas.height = cropH;
    cropCanvas
      .getContext("2d")
      .drawImage(canvas, cropX, cropY, cropW, cropH, 0, 0, cropW, cropH);

    const dataUrl = cropCanvas.toDataURL("image/png");

    const draggableImg = document.createElement("img");
    draggableImg.src = dataUrl;
    draggableImg.className = "draggable-pancake pulsing is-draggable";

    // Gunakan persentase agar tahan terhadap rescale / responsive layout
    draggableImg.style.position = "absolute";
    draggableImg.style.left = (cropX / canvas.width * 100) + "%";
    draggableImg.style.top = (cropY / canvas.height * 100) + "%";
    draggableImg.style.width = (cropW / canvas.width * 100) + "%";
    draggableImg.style.height = (cropH / canvas.height * 100) + "%";
    draggableImg.style.zIndex = "100";

    pan.appendChild(draggableImg);

    let hintArrow = null;
    let showHint = config.showDragHintAlways ? true : (drawCount === 0);

    if (showHint) {
      const colors = config.drawColors || ["#F3C550"];
      const currentColor = colors[drawCount % colors.length];

      hintArrow = document.createElement("div");
      hintArrow.className = "drag-hint-arrow";
      hintArrow.innerHTML = `
        <svg width="100" height="100" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
          <path d="M 15 35 Q 15 25 25 25 L 55 25 L 55 15 Q 55 5 65 12 L 92 46 Q 98 50 92 54 L 65 88 Q 55 95 55 85 L 55 75 L 25 75 Q 15 75 15 65 Z" fill="${currentColor}" stroke="#FFFFFF" stroke-width="6" stroke-linejoin="round"/>
        </svg>
      `;

      // Tambahkan ke pan agar posisinya relatif terhadap wajan
      hintArrow.style.left = "94%"; // di sebelah kanan wajan
      hintArrow.style.top = "34%";
      pan.appendChild(hintArrow);

      // Event listener: jika panah di-klik/tap, kue otomatis pindah
      hintArrow.addEventListener("click", () => {
        if (hintArrow) {
          hintArrow.remove();
          hintArrow = null;
        }

        // Animasi terbang ke arah piring
        draggableImg.classList.remove("pulsing");
        draggableImg.style.transition = "all 0.6s ease-in-out";
        draggableImg.style.left = "125%";
        draggableImg.style.top = "20%";
        draggableImg.style.width = "35%";
        draggableImg.style.height = "35%";
        draggableImg.style.opacity = "0";

        // Panggil drop sukses setelah animasi selesai
        timeouts.push(setTimeout(() => {
          handleSuccessDrop(draggableImg, dataUrl);
        }, 600));
      });
    }

    // Bersihkan canvas agar tidak double
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    canvas.style.pointerEvents = "none";

    // Implement drag events
    let startMouseX, startMouseY;
    let startImgLeftPct, startImgTopPct;
    let isDragging = false;

    function onDragStart(e) {
      e.preventDefault();
      isDragging = true;
      draggableImg.classList.remove("pulsing");
      draggableImg.classList.add("dragging");

      if (hintArrow) {
        hintArrow.remove();
        hintArrow = null;
      }

      let clientX = e.touches ? e.touches[0].clientX : e.clientX;
      let clientY = e.touches ? e.touches[0].clientY : e.clientY;

      startMouseX = clientX;
      startMouseY = clientY;

      // Ambil posisi awal dalam bentuk persentase
      startImgLeftPct = parseFloat(draggableImg.style.left) || 0;
      startImgTopPct = parseFloat(draggableImg.style.top) || 0;

      activeDragCleanup = () => {
        document.removeEventListener("mousemove", onDragMove);
        document.removeEventListener("touchmove", onDragMove);
        document.removeEventListener("mouseup", onDragEnd);
        document.removeEventListener("touchend", onDragEnd);
      };

      document.addEventListener("mousemove", onDragMove);
      document.addEventListener("touchmove", onDragMove, { passive: false });
      document.addEventListener("mouseup", onDragEnd);
      document.addEventListener("touchend", onDragEnd);
    }

    function onDragMove(e) {
      if (!isDragging) return;
      e.preventDefault();
      let clientX = e.touches ? e.touches[0].clientX : e.clientX;
      let clientY = e.touches ? e.touches[0].clientY : e.clientY;

      let dx = clientX - startMouseX;
      let dy = clientY - startMouseY;

      // Konversi pergerakan pixel ke persentase berdasarkan ukuran wajan saat ini di layar
      const panRect = pan.getBoundingClientRect();
      let dxPct = (dx / panRect.width) * 100;
      let dyPct = (dy / panRect.height) * 100;

      draggableImg.style.left = (startImgLeftPct + dxPct) + "%";
      draggableImg.style.top = (startImgTopPct + dyPct) + "%";
    }

    function onDragEnd(e) {
      if (!isDragging) return;
      isDragging = false;
      draggableImg.classList.remove("dragging");

      document.removeEventListener("mousemove", onDragMove);
      document.removeEventListener("touchmove", onDragMove);
      document.removeEventListener("mouseup", onDragEnd);
      document.removeEventListener("touchend", onDragEnd);
      activeDragCleanup = null;

      let rectImg = draggableImg.getBoundingClientRect();
      let plateArea = container.querySelector(".drawing-plate") || container.querySelector(".plate-area-container");
      let rectPlate = plateArea ? plateArea.getBoundingClientRect() : { left: window.innerWidth / 2, right: window.innerWidth, top: 0, bottom: window.innerHeight };

      let centerX = rectImg.left + rectImg.width / 2;

      // Hit detection yang sangat pemaaf: jika kue menyentuh area talenan, atau pusatnya berada di paruh kanan layar (area talenan)
      let isHit = false;
      if (rectImg.right > rectPlate.left && rectImg.left < rectPlate.right &&
        rectImg.bottom > rectPlate.top && rectImg.top < rectPlate.bottom) {
        isHit = true;
      } else if (centerX > window.innerWidth * 0.55) {
        // Jika setidaknya melewati tengah layar ke arah kanan
        isHit = true;
      }

      if (isHit) {
        handleSuccessDrop(draggableImg, dataUrl);
      } else {
        // Snap back
        draggableImg.classList.add("pulsing");
        draggableImg.style.transition = "all 0.3s ease-out";
        // Kembalikan ke posisi awal
        draggableImg.style.left = (cropX / canvas.width * 100) + "%";
        draggableImg.style.top = (cropY / canvas.height * 100) + "%";

        timeouts.push(setTimeout(() => {
          draggableImg.style.transition = "";
        }, 350));
      }
    }

    draggableImg.addEventListener("mousedown", onDragStart);
    draggableImg.addEventListener("touchstart", onDragStart, { passive: false });
  }

  function handleSuccessDrop(dragImg, dataUrl) {
    dragImg.remove();
    canvas.style.pointerEvents = "auto";

    if (typeof sounds !== "undefined" && sounds.playChime) sounds.playChime();

    // 2. Buat elemen gambar baru untuk piring
    const img = document.createElement("img");
    img.src = dataUrl;
    img.className = "stacked-pancake";

    if (config.styles?.pancake) {
      img.setAttribute("style", config.styles.pancake);
    }

    const randomRotation = (Math.random() - 0.5) * 30; // -15 deg sampai +15 deg
    const randomX = (Math.random() - 0.5) * 20;
    const randomY = (Math.random() - 0.5) * 20;

    const baseTransform = img.style.transform
      ? img.style.transform + " "
      : "translate(-50%, -50%) ";
    img.style.transform =
      baseTransform +
      `rotate(${randomRotation}deg) translate(${randomX}px, ${randomY}px)`;

    // 3. Masukkan ke tumpukan piring
    plateStack.appendChild(img);

    hasDrawnCurrent = false;
    bounds = {
      minX: Infinity,
      minY: Infinity,
      maxX: -Infinity,
      maxY: -Infinity,
    };
    btnFinish.classList.add("hidden"); // Optional

    // 5. Tambah counter
    drawCount++;

    // Update star indicator if it exists
    const stars = document.querySelectorAll('.drawing-star');
    if (stars && stars.length >= drawCount) {
      const currentStar = stars[drawCount - 1];
      if (currentStar) {
        currentStar.setAttribute('fill', config.starColorActive || '#F3C550');
        currentStar.style.fill = config.starColorActive || '#F3C550';
        currentStar.style.transform = 'scale(1.5)';
        timeouts.push(setTimeout(() => {
          if (currentStar) currentStar.style.transform = 'scale(1)';
        }, 300));
      }
    }

    // 6. Update warna untuk giliran berikutnya
    setupContext();

    if (drawCount >= maxDraws) {
      endGame();
    }
  }

  function endGame() {
    // Sembunyikan pan dan tombol selesai
    pan.style.opacity = "0.5";
    pan.style.pointerEvents = "none"; // Matikan interaksi canvas

    // Tampilkan tombol lanjut
    btnNext.classList.remove("hidden");

    if (window.triggerGameWinCelebration) {
      window.triggerGameWinCelebration(
        feedback,
        feedback.getAttribute("data-correct-text"),
        config.hideCorrectSpeechBtn,
      );
    } else {
      // Tampilkan feedback benar
      const text = feedback.getAttribute("data-correct-text");
      window.showGameFeedback(
        feedback,
        `<span style="color:var(--color-grass-dark)">${text}</span>`,
        text,
        feedback.getAttribute("data-correct-audio"),
        config.hideCorrectSpeechBtn,
      );
      feedback.classList.add("feedback-correct");

      // Mainkan suara sukses
      if (typeof sounds !== "undefined" && sounds.playSuccess)
        sounds.playSuccess();
    }
  }
};
