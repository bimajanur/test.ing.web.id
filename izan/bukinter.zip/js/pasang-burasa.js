window.initPasangBurasaGame = function (container, spread = {}) {
  const draggables = container.querySelectorAll(".draggable-item");
  const dropZones = container.querySelectorAll(".drop-zone-container");
  const feedback = container.querySelector(".drag-feedback");
  const nextBtn = container.querySelector(".next-level-btn");
  const tyingOverlay = container.querySelector("#tying-phase-container");
  const dragItemsList = container.querySelector(".drag-items-list");
  const dropZonesList = container.querySelector(".drop-zones-list");

  if (!draggables.length || !dropZones.length) return;

  if (feedback && spread.startInstruction) {
    const text = spread.startInstruction;
    window.showGameFeedback(
      feedback,
      `<span style="color:var(--color-wood-dark)">${text}</span>`,
      text,
      spread.startAudio,
      spread.hideStartSpeechBtn,
    );
  }

  let feedbackTimeout = null;
  let completedZones = 0;
  // Exclude dummy drop zones from the total count
  const activeDropZones = Array.from(dropZones).filter(
    (dz) => dz.dataset.target !== "dummy",
  );
  const totalZones = activeDropZones.length;

  // Phase 2 State
  let currentTyingStep = 0;
  let tyingSteps = spread.tyingSteps || [];

  const cleanups = [];
  const timeouts = [];
  if (window.activeGameCleanup) {
    window.activeGameCleanup();
  }
  window.activeGameCleanup = () => {
    cleanups.forEach((cb) => cb());
    timeouts.forEach((id) => clearTimeout(id));
  };

  function initTyingPhase() {
    if (!tyingOverlay || tyingSteps.length === 0) {
      finishGame();
      return;
    }

    if (feedback) feedback.classList.add("hidden");

    // Fade out phase 1 items
    if (dragItemsList) {
      dragItemsList.style.transition = "opacity 0.5s ease";
      dragItemsList.style.opacity = "0";
    }
    if (dropZonesList) {
      dropZonesList.style.transition = "opacity 0.5s ease";
      dropZonesList.style.opacity = "0";
    }

    // Show tying phase container
    timeouts.push(setTimeout(() => {
      if (dragItemsList) dragItemsList.classList.add("hidden");
      if (dropZonesList) dropZonesList.classList.add("hidden");

      tyingOverlay.classList.remove("hidden");
      timeouts.push(setTimeout(() => {
        tyingOverlay.style.opacity = "1";
        setupTyingStep(currentTyingStep);

        if (feedback) {
          const text = spread.tyingInstruction || "Ikuti arah panah";
          window.showGameFeedback(
            feedback,
            `<span style="color:var(--color-wood-dark)">${text}</span>`,
            text,
            spread.tyingAudio,
            spread.hideTyingSpeechBtn,
          );
        }
      }, 50));
    }, 500));
  }

  function setupTyingStep(stepIndex) {
    if (stepIndex >= tyingSteps.length) {
      finishGame();
      // Remove the tying knob and hint to clean up the UI
      const hintImg = tyingOverlay.querySelector("#tying-hint");
      const knob = tyingOverlay.querySelector("#tying-knob");
      if (hintImg) hintImg.style.display = "none";
      if (knob) knob.style.display = "none";
      return;
    }

    const step = tyingSteps[stepIndex];
    const hintImg = tyingOverlay.querySelector("#tying-hint");
    let knob = tyingOverlay.querySelector("#tying-knob");

    // Clean up old listeners if they exist by replacing the node FIRST
    const newKnob = knob.cloneNode(true);
    knob.parentNode.replaceChild(newKnob, knob);
    knob = newKnob; // Now knob points to the active DOM element!

    hintImg.src = step.hintSrc;
    knob.style.left = step.startX;
    knob.style.top = step.startY;

    // Reset knob style
    knob.style.transform = "translate(-50%, -50%) scale(1)";

    let isDraggingKnob = false;
    let activeTyingDragCleanup = null;

    const tyingContainer = tyingOverlay.querySelector(".tying-container");

    // Convert end percentages to pixels relative to container for distance checking
    const parsePercent = (val) => parseFloat(val) / 100;
    const threshold = 40; // Unscaled pixel threshold for success

    const handleKnobStart = (e) => {
      isDraggingKnob = true;
      knob.style.animation = "none"; // Stop pulse
      knob.style.transform = "translate(-50%, -50%) scale(1.2)";

      // Cache rect and scale on start to avoid layout trashing
      const rect = tyingContainer.getBoundingClientRect();
      const scale = Math.min(window.innerWidth / 1280, window.innerHeight / 720) || 1;

      const handleKnobMove = (e) => {
        if (!isDraggingKnob) return;
        e.preventDefault();

        const clientX = e.type.includes("mouse")
          ? e.clientX
          : e.touches[0].clientX;
        const clientY = e.type.includes("mouse")
          ? e.clientY
          : e.touches[0].clientY;

        // Convert client coordinates to unscaled container coordinates
        let x = (clientX - rect.left) / scale;
        let y = (clientY - rect.top) / scale;

        const unscaledWidth = rect.width / scale;
        const unscaledHeight = rect.height / scale;

        // Constrain within container
        x = Math.max(0, Math.min(x, unscaledWidth));
        y = Math.max(0, Math.min(y, unscaledHeight));

        knob.style.left = `${x}px`;
        knob.style.top = `${y}px`;

        // Check distance to end target
        const endX_unscaled = parsePercent(step.endX) * unscaledWidth;
        const endY_unscaled = parsePercent(step.endY) * unscaledHeight;
        const dist = Math.hypot(x - endX_unscaled, y - endY_unscaled);
        if (dist < threshold) {
          if (activeTyingDragCleanup) activeTyingDragCleanup();
          completeTyingStep();
        }
      };

      const handleKnobEnd = (e) => {
        if (!isDraggingKnob) return;
        if (activeTyingDragCleanup) activeTyingDragCleanup();

        // If released but not close enough, snap back to start
        knob.style.animation = "pulse-knob 1.5s infinite";
        knob.style.left = step.startX;
        knob.style.top = step.startY;
        knob.style.transform = "translate(-50%, -50%) scale(1)";
      };

      activeTyingDragCleanup = () => {
        isDraggingKnob = false;
        document.removeEventListener("mousemove", handleKnobMove);
        document.removeEventListener("mouseup", handleKnobEnd);
        document.removeEventListener("touchmove", handleKnobMove);
        document.removeEventListener("touchend", handleKnobEnd);
        activeTyingDragCleanup = null;
      };

      document.addEventListener("mousemove", handleKnobMove, { passive: false });
      document.addEventListener("mouseup", handleKnobEnd);
      document.addEventListener("touchmove", handleKnobMove, { passive: false });
      document.addEventListener("touchend", handleKnobEnd);
    };

    knob.addEventListener("mousedown", handleKnobStart);
    knob.addEventListener("touchstart", handleKnobStart, { passive: true });

    cleanups.push(() => {
      knob.removeEventListener("mousedown", handleKnobStart);
      knob.removeEventListener("touchstart", handleKnobStart);
      if (activeTyingDragCleanup) activeTyingDragCleanup();
    });
  }

  function completeTyingStep() {
    const step = tyingSteps[currentTyingStep];
    const resultsLayer = tyingOverlay.querySelector("#tying-results-layer");

    // Add result image to layer
    const resultImg = document.createElement("img");
    resultImg.src = step.doneSrc;
    resultImg.style.width = "100%";
    resultImg.style.position = "absolute";
    resultImg.style.top = "0";
    resultImg.style.left = "0";
    resultImg.style.zIndex = "3";
    resultsLayer.appendChild(resultImg);

    if (typeof sounds !== "undefined" && sounds.playChime) sounds.playChime();

    currentTyingStep++;
    setupTyingStep(currentTyingStep);
  }

  function finishGame() {
    if (tyingOverlay) tyingOverlay.style.pointerEvents = "none";
    if (nextBtn) {
      nextBtn.classList.remove("hidden");
    }
    if (window.triggerGameWinCelebration) {
      window.triggerGameWinCelebration(
        feedback,
        spread.feedbackTyingDone || "Wah hebat, semua burasa sudah diikat!",
        spread.hideCorrectSpeechBtn,
        spread.feedbackTyingDoneAudio || "",
      );
    }
  }

  draggables.forEach((item) => {
    let hasSuccessfullyDropped = false;

    const cleanupDrag = window.setupDraggable(item, {
      rotation: 35,
      scale: 1.1,
      shouldLock: () => hasSuccessfullyDropped && item.dataset.target === "",
      onEnd: ({ dragScale, resetPosition, snapBack }) => {
        const collidedZone = window.checkCollision(item, dropZones, dragScale, {
          padding: 20,
          useDistance: true,
          cropItemRect: false
        });

        if (collidedZone) {
          const isCorrectTarget =
            item.dataset.target &&
            item.dataset.target === collidedZone.dataset.target;
          const isLegacyCorrect =
            !item.dataset.target && item.dataset.correct === "true";

          if (isCorrectTarget || isLegacyCorrect) {
            resetPosition();
            hasSuccessfullyDropped = true;

            const dropZoneImg =
              collidedZone.querySelector(".drop-zone-img") ||
              collidedZone.querySelector("#drop-zone-img");
            if (dropZoneImg && !collidedZone.dataset.completed) {
              if (collidedZone.dataset.dynamicSrc === "true") {
                dropZoneImg.src = item.src;
              } else {
                dropZoneImg.src = dropZoneImg.dataset.doneSrc;
              }
              collidedZone.dataset.completed = "true";
              completedZones++;

              if (item.dataset.hideOnDrop === "true") {
                item.style.opacity = "0";
                item.style.pointerEvents = "none";
              }
            }

            if (typeof sounds !== "undefined" && sounds.playChime)
              sounds.playChime();

            if (completedZones >= totalZones) {
              if (feedback) {
                const text = spread.feedbackCorrect || "Hore, burasanya sudah berpasangan sekarang!";
                window.showGameFeedback(
                  feedback,
                  `<span style="color:var(--color-grass-dark)">${text}</span>`,
                  text,
                  spread.feedbackCorrectAudio || "",
                  spread.hideCorrectSpeechBtn,
                );
              }

              const btnIkat = document.createElement("button");
              btnIkat.className = "bouncy-btn start-btn";
              btnIkat.innerHTML = "Ikat Burasa ➔";
              btnIkat.style.position = "absolute";
              btnIkat.style.top = "50%";
              btnIkat.style.left = "50%";
              btnIkat.style.transform = "translate(-50%, -50%)";
              btnIkat.style.zIndex = "99999";
              btnIkat.style.fontSize = "1.5rem";
              btnIkat.style.padding = "15px 30px";
              btnIkat.style.display = "block";
              btnIkat.onclick = () => {
                if (window.stopSpeech) {
                  window.stopSpeech();
                }
                if (typeof sounds !== 'undefined' && sounds.playPop) sounds.playPop();
                btnIkat.remove();
                initTyingPhase();
              };
              
              const activePopup = document.querySelector(".game-popup-overlay:not(.hidden) .game-popup-content");
              if (activePopup) {
                activePopup.appendChild(btnIkat);
              } else if (feedback && feedback.parentElement) {
                feedback.parentElement.appendChild(btnIkat);
              } else {
                document.body.appendChild(btnIkat);
              }
            } else {
              if (feedback) {
                const text = spread.feedbackDrop || "Hap!";
                window.showGameFeedback(
                  feedback,
                  `<span style="color:var(--color-grass-dark)">${text}</span>`,
                  text,
                  spread.feedbackDropAudio,
                  spread.hideDropSpeechBtn,
                );
              }
            }
          } else {
            resetPosition();

            if (typeof sounds !== "undefined" && sounds.playWrong)
              sounds.playWrong();

            if (feedback) {
              const text = feedback.dataset.incorrectText;
              window.showGameFeedback(
                feedback,
                `<span style="color:#C0392B">${text}</span>`,
                text,
                feedback.dataset.incorrectAudio,
                spread.hideIncorrectSpeechBtn,
              );
            }
          }
        } else {
          snapBack();
        }
      }
    });

    cleanups.push(cleanupDrag);
  });
};
