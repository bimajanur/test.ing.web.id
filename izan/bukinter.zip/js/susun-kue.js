window.initSusunKue = function (container, spread = {}) {
  const draggables = container.querySelectorAll(".draggable-item");
  const dropZones = container.querySelectorAll(".drop-zone-container");
  const feedback = container.querySelector(".drag-feedback");

  if (!draggables.length || !dropZones.length) return;

  if (feedback && spread.startInstruction) {
    const text = spread.startInstruction;
    window.showGameFeedback(
      feedback,
      `<span style="color:var(--color-wood-dark)">${text}</span>`,
      text,
      spread.startAudio,
      spread.hideStartSpeechBtn,
    );
  }

  let completedZones = 0;
  // Calculate total zones dynamically (excluding dummy zones)
  const totalZones = Array.from(dropZones).filter(
    (dz) => dz.dataset.target !== "dummy",
  ).length;

  const cleanups = [];
  if (window.activeGameCleanup) {
    window.activeGameCleanup();
  }
  window.activeGameCleanup = () => {
    cleanups.forEach((cb) => cb());
  };

  draggables.forEach((item) => {
    let hasSuccessfullyDropped = false;

    const cleanupDrag = window.setupDraggable(item, {
      rotation: 35,
      scale: 1.1,
      shouldLock: () => hasSuccessfullyDropped && item.dataset.target === "",
      onEnd: ({ dragScale, resetPosition, snapBack }) => {
        const collidedZone = window.checkCollision(item, dropZones, dragScale, {
          cropItemRect: false
        });

        if (collidedZone) {
          const isCorrectTarget =
            item.dataset.target &&
            item.dataset.target === collidedZone.dataset.target;
          const isLegacyCorrect =
            !item.dataset.target && item.dataset.correct === "true";

          if (isCorrectTarget || isLegacyCorrect) {
            // Success
            resetPosition();
            hasSuccessfullyDropped = true;

            const dropZoneImg =
              collidedZone.querySelector(".drop-zone-img") ||
              collidedZone.querySelector("#drop-zone-img");
            if (dropZoneImg && !collidedZone.dataset.completed) {
              if (collidedZone.dataset.dynamicSrc === "true") {
                dropZoneImg.src = item.src;
              } else {
                dropZoneImg.src = dropZoneImg.dataset.doneSrc;
              }
              collidedZone.dataset.completed = "true";
              completedZones++;

              if (item.dataset.hideOnDrop === "true") {
                item.style.opacity = "0";
                item.style.pointerEvents = "none";
              }
            }

            if (typeof sounds !== "undefined" && sounds.playChime)
              sounds.playChime();

            if (feedback) {
              const text = feedback.dataset.correctText || "Bagus!";
              window.showGameFeedback(
                feedback,
                `<span style="color:var(--color-grass-dark)">${text}</span>`,
                text,
                feedback.dataset.correctAudio,
                spread.hideCorrectSpeechBtn,
              );
            }

            if (completedZones >= totalZones) {
              const nextBtn = feedback
                ?.closest(".game-popup-content")
                ?.querySelector(".next-level-btn");
              if (nextBtn) nextBtn.classList.remove("hidden");

              const winText = spread.feedbackWin || "Semua sudah sesuai! Hebat!";
              const winAudio = spread.feedbackWinAudio || feedback.dataset.correctAudio || "";

              if (window.triggerGameWinCelebration) {
                window.triggerGameWinCelebration(
                  feedback,
                  winText,
                  spread.hideCorrectSpeechBtn,
                  winAudio,
                );
              } else if (feedback) {
                window.showGameFeedback(
                  feedback,
                  `<span style="color:var(--color-grass-dark)">${winText}</span>`,
                  winText,
                  winAudio,
                  spread.hideCorrectSpeechBtn,
                );
              }
            }
          } else {
            // Incorrect
            resetPosition();

            if (typeof sounds !== "undefined" && sounds.playWrong)
              sounds.playWrong();

            if (feedback) {
              const text = feedback.dataset.incorrectText || "Coba lagi!";
              window.showGameFeedback(
                feedback,
                `<span style="color:#C0392B">${text}</span>`,
                text,
                feedback.dataset.incorrectAudio,
                spread.hideIncorrectSpeechBtn,
              );
            }
          }
        } else {
          snapBack();
        }
      }
    });

    cleanups.push(cleanupDrag);
  });
};
