window.initDragDrop = function (container, spread = {}) {
  const draggables = container.querySelectorAll(".draggable-item");
  const dropZones = container.querySelectorAll(".drop-zone-container");
  const feedback = container.querySelector(".drag-feedback");
  const nextBtn = container.querySelector(".next-level-btn");

  if (!draggables.length || !dropZones.length) return;

  if (feedback && spread.startInstruction) {
    const text = spread.startInstruction;
    window.showGameFeedback(
      feedback,
      `<span style="color:var(--color-wood-dark)">${text}</span>`,
      text,
      spread.startAudio,
      spread.hideStartSpeechBtn,
    );
  }

  let completedZones = 0;
  const totalZones = dropZones.length;

  const cleanups = [];
  if (window.activeGameCleanup) {
    window.activeGameCleanup();
  }
  window.activeGameCleanup = () => {
    cleanups.forEach((cb) => cb());
  };

  draggables.forEach((item) => {
    let hasSuccessfullyDropped = false;

    const cleanupDrag = window.setupDraggable(item, {
      rotation: 35,
      scale: 1.1,
      shouldLock: () => hasSuccessfullyDropped && item.dataset.target === "",
      onEnd: ({ dragScale, resetPosition, snapBack }) => {
        const collidedZone = window.checkCollision(item, dropZones, dragScale, {
          cropItemRect: true
        });

        if (collidedZone) {
          const isCorrectTarget =
            item.dataset.target &&
            item.dataset.target === collidedZone.dataset.target;
          const isLegacyCorrect =
            !item.dataset.target && item.dataset.correct === "true";

          if (isCorrectTarget || isLegacyCorrect) {
            resetPosition();
            hasSuccessfullyDropped = true;

            const dropZoneImg =
              collidedZone.querySelector(".drop-zone-img") ||
              collidedZone.querySelector("#drop-zone-img");
            if (dropZoneImg && !collidedZone.dataset.completed) {
              dropZoneImg.src = dropZoneImg.dataset.doneSrc;
              collidedZone.dataset.completed = "true";
              completedZones++;

              if (item.dataset.hideOnDrop === "true") {
                item.style.opacity = "0";
                item.style.pointerEvents = "none";
              }
            }

            if (typeof sounds !== "undefined" && sounds.playChime)
              sounds.playChime();

            if (feedback) {
              const text = feedback.dataset.correctText;
              window.showGameFeedback(
                feedback,
                `<span style="color:var(--color-grass-dark)">${text}</span>`,
                text,
                feedback.dataset.correctAudio,
                spread.hideCorrectSpeechBtn,
              );
            }

            if (completedZones >= totalZones) {
              if (nextBtn) {
                nextBtn.classList.remove("hidden");
              }
              const winText = spread.feedbackWin || "Semua sudah sesuai! Hebat!";
              const winAudio = spread.feedbackWinAudio || feedback.dataset.correctAudio || "";
              if (window.triggerGameWinCelebration) {
                window.triggerGameWinCelebration(
                  feedback,
                  winText,
                  spread.hideCorrectSpeechBtn,
                  winAudio,
                );
              } else if (feedback) {
                window.showGameFeedback(
                  feedback,
                  `<span style="color:var(--color-grass-dark)">${winText}</span>`,
                  winText,
                  winAudio,
                  spread.hideCorrectSpeechBtn,
                );
              }
            }
          } else {
            resetPosition();

            if (typeof sounds !== "undefined" && sounds.playWrong)
              sounds.playWrong();

            if (feedback) {
              const text = feedback.dataset.incorrectText;
              window.showGameFeedback(
                feedback,
                `<span style="color:#C0392B">${text}</span>`,
                text,
                feedback.dataset.incorrectAudio,
                spread.hideIncorrectSpeechBtn,
              );
            }
          }
        } else {
          snapBack();
        }
      }
    });

    cleanups.push(cleanupDrag);
  });
};
